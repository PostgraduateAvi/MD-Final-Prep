# 📚 MD Final Prep — Internal Medicine Theory Repository

Welcome to your **master preparation hub** for MD Internal Medicine final university theory exams. This GitHub repository is your structured, version-controlled storage for everything from PYQs to schematic diagrams and notes.

---

## 🔖 Repository Structure

```
MD-Final-Prep/
│
├── PYQs/                         ← CSV or Excel files of past questions
│   ├── pyq_by_system.csv
│   └── pyq_by_harrison_chapter.csv
│
├── Notes/                        ← Typed notes or PDF exports of hand notes
│   ├── Cardiology.md
│   ├── Nephrology.md
│   └── Endocrinology.md
│
├── Images/                       ← Flowcharts, tables, radiology images
│   ├── anemia-algo.png
│   └── dka-management.jpg
│
├── Guidelines/                   ← NICE, CDC, NEJM PDFs
│   └── NICE_HF_2024.pdf
│
└── README.md                     ← This file
```

---

## 📌 Purpose

This repo allows you to:

- Organize all MD theory material in one place
- Tag and retrieve PYQs by system/chapter
- Generate AI-based MCQs, schematics, and answer-writing guidance
- Track your progress across specialties
- Collaborate or share notes securely (optional)

---

## 📤 How to Upload Files (No Coding Needed)

1. Click the `Add file` button above → `Upload files`
2. Drag and drop your files into the correct folder (e.g., `Notes/`)
3. Click **"Commit changes"**

---

## 🧠 Suggested File Types

- `.csv` for structured past paper data  
- `.md` for text notes (or `.pdf`/.docx if easier)  
- `.png`, `.jpg`, or `.svg` for diagrams  
- `.pdf` for scanned notes and guidelines

---

## 👨‍⚕️ How This Works With AI

Once your content is uploaded, The First Principles Physician can:

- Extract MCQs and answers from your CSVs
- Use your notes and flowcharts for custom answer generation
- Convert PYQs into structured theory answers
- Provide spaced revision plans and quizzes

---

## 🛡 License

Private study use only. Please do not upload copyrighted material unless you own it or have permission.

---

## 🤝 Contributions

This is your personal study repo. You can optionally invite a study buddy via:
`Settings > Collaborators > Add by GitHub username`

---

🧠 *Be the master of your content. Learn by first principles. Crush your MD theory.*  
